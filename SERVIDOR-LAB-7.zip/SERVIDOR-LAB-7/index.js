// importa o express
const express = require("express");

// cria o servidor
const app = express();


// define a porta 80
const PORT = 80;


// define a pasta public como arquivos estáticos
app.use(express.static("public"));


// inicia o servidor
app.listen(PORT, () => {

  console.log("Servidor online na porta 80");

});