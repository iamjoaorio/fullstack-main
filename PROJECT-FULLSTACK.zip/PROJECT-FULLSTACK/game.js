// ================================================
// CONFIGURAÇÃO DO CANVAS
// Aqui o programa pega o espaço de desenho do HTML
// e ativa o modo de desenho 2D
// ================================================

// pega o elemento canvas do HTML pelo ID
var canvas = document.getElementById("gameCanvas");

// ativa o modo de desenho 2D do canvas
var ctx = canvas.getContext("2d");


// ================================================
// PISTAS DO JOGO
// O jogo tem 3 faixas. Cada número é o centro
// de uma faixa na tela (posição horizontal)
// ================================================
var pistas = [150, 300, 450];


// ================================================
// CARREGAMENTO DAS IMAGENS
// Aqui o programa carrega todas as imagens
// que serão usadas no jogo
// ================================================

// imagem do jogador (personagem principal)
var imgJogador = new Image();
imgJogador.src = "./content/player main-Photoroom.png";

// imagem do item bom (CLT - carteira de trabalho)
var imgClt = new Image();
imgClt.src = "./content/da110085deb77491bfc74e0db9e66f2a-Photoroom.png";

// primeira imagem de inimigo
var imgInimigo1 = new Image();
imgInimigo1.src = "./content/betano.jpg";

// segunda imagem de inimigo
var imgInimigo2 = new Image();
imgInimigo2.src = "./content/7891149200504--1--Photoroom.png";


// ================================================
// DADOS DO JOGADOR
// Aqui ficam guardadas todas as informações
// sobre o personagem que o jogador controla
// ================================================
var jogador = {

 
  // 0 = faixa da esquerda
  // 1 = faixa do meio
  // 2 = faixa da direita
  pista: 1,

  // posição horizontal do jogador
  x: pistas[1],

  // posição vertica
  y: 650,

  // em pixels
  largura: 50,
  altura: 50
};


// ================================================
// VARIÁVEIS GERAIS DO JOGO
// ================================================

// lista de todos os itens que aparecem na tela (começa vazia)
var itens = [];

// quantidade de pontos que o jogador tem
var pontos = 0;

// quantidade de vidas que o jogador tem
var vidas = 3;

// velocidade com que os itens descem pela tela
var velocidade = 2;

// contador de frames (cada frame = 1 chamada do loop)
var contador = 0;


// ================================================
// CONTROLES DO TECLADO
// O programa fica "ouvindo" o teclado
// e reage quando alguma tecla é pressionada
// ================================================
document.addEventListener("keydown", function(evento) {

  // se apertar A ou tecla de seta esquerda: vai para esquerda
  if (evento.key === "a" || evento.key === "A" || evento.key === "ArrowLeft") {

    // só muda de pista se não estiver na primeira (mais à esquerda)
    if (jogador.pista > 0) {

      // diminui o número da pista (vai para a pista de cima)
      jogador.pista = jogador.pista - 1;
    }
  }

  // se apertar D ou tecla de seta direita: vai para direita
  if (evento.key === "d" || evento.key === "D" || evento.key === "ArrowRight") {

    // só muda de pista se não estiver na última (mais à direita)
    if (jogador.pista < 2) {

      // aumenta o número da pista (vai para a pista de baixo)
      jogador.pista = jogador.pista + 1;
    }
  }
});


// ================================================
// FUNÇÃO: CRIAR ITEM
// Essa função coloca um novo item na parte de cima
// da tela. O item pode ser bom (CLT) ou inimigo
// ================================================
function criarItem() {

  // sorteia aleatoriamente uma das 3 pistas (0, 1 ou 2)
  var pistaAleatoria = Math.floor(Math.random() * 3);

  // gera um número entre 0 e 1 para decidir o tipo do item
  var sorteio = Math.random();

  // variáveis que vão guardar o tipo e a imagem do item
  var tipo;
  var imagem;

  // 30% de chance de criar um item bom (CLT)
  if (sorteio < 0.3) {

    // define o tipo como CLT (item bom)
    tipo = "clt";

    // define a imagem do item bom
    imagem = imgClt;

  } else {

    // define o tipo como inimigo (item ruim)
    tipo = "inimigo";

    // escolhe aleatoriamente qual das duas imagens de inimigo usar
    if (Math.random() < 0.5) {
      imagem = imgInimigo1;
    } else {
      imagem = imgInimigo2;
    }
  }

  // cria o objeto que representa o novo item
  var novoItem = {

    // posição horizontal baseada na pista sorteada
    // o -25 serve para centralizar o item na pista
    x: pistas[pistaAleatoria] - 25,

    // começa acima da tela (fora de vista)
    y: -50,

    // tamanho do item
    largura: 50,
    altura: 50,

    // tipo do item (clt ou inimigo)
    tipo: tipo,

    // qual imagem esse item usa
    imagem: imagem
  };

  // adiciona o item novo na lista de itens
  itens.push(novoItem);
}


// ================================================
// FUNÇÃO: VERIFICAR COLISÃO
// Essa função checa se dois objetos estão se tocando
// Se sim, retorna true. Se não, retorna false
// ================================================
function temColisao(a, b) {

  // margem de tolerância para a colisão parecer mais justa
  // sem isso a colisão pode parecer errada visualmente
  var margem = 10;

  // verifica se o lado direito de A não chega até o lado esquerdo de B
  if (a.x + margem > b.x + b.largura - margem) return false;

  if (a.x + a.largura - margem < b.x + margem) return false;

  if (a.y + margem > b.y + b.altura - margem) return false;

  // 
  if (a.y + a.altura - margem < b.y + margem) return false;

  // se passou por todas as verificações acima, houve colisão!
  return true;
}


// ================================================
// FUNÇÃO: ATUALIZAR
// Essa função é chamada a cada frame do jogo
// Ela atualiza toda a lógica: posições, pontos, vidas
// ================================================
function atualizar() {

  // atualiza a posição horizontal do jogador de acordo com a pista atual
  jogador.x = pistas[jogador.pista] - jogador.largura / 2;

  // aumenta o contador de frames em 1
  contador = contador + 1;

  // (aproximadamente 1 segundo)
  if (contador % 60 === 0) {
    criarItem();
  }

  // (aproximadamente 10 segundos), aumenta a velocidade
  if (contador % 600 === 0) {
    velocidade = velocidade + 0.3;
  }

  // percorre a lista de itens de trás para frente
  // percorrer de trás para frente facilita remover itens sem erro
  for (var i = itens.length - 1; i >= 0; i--) {

    // pega o item atual da lista
    var item = itens[i];

    // faz o item descer pela velocidade atual
    item.y = item.y + velocidade;

    // verifica se houve colisão entre o jogador e esse item
    if (temColisao(jogador, item)) {

      // se o item for do tipo CLT, ganha 10 pontos
      if (item.tipo === "clt") {
        pontos = pontos + 10;

      } else {

        // se for inimigo, perde 1 vida
        vidas = vidas - 1;
      }

      // remove o item da lista após a colisão
      itens.splice(i, 1);

    } else if (item.y > canvas.height) {

      // se o item saiu da tela pelo rodapé, remove ele da lista
      itens.splice(i, 1);
    }
  }

  // verifica se o jogador ficou sem vidas
  if (vidas <= 0) {

    // mostra uma mensagem com a pontuação final
    alert("💀 Game Over! Sua pontuação foi: " + pontos + " pontos");

    // reinicia a página para começar um novo jogo
    document.location.reload();
  }
}


// ================================================
// FUNÇÃO: DESENHAR HUD
// Aqui fica o placar (pontos e vidas) na tela
// Desenhado com estilo neon para combinar com o jogo
// ================================================
function desenharHud() {

  // ---- PAINEL DE PONTOS (canto superior esquerdo) ----

 
  ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
  ctx.beginPath();
  ctx.roundRect(10, 10, 160, 50, 8);
  ctx.fill();


  ctx.strokeStyle = "rgba(0, 240, 255, 0.5)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(10, 10, 160, 50, 8);
  ctx.stroke();

  // texto "PONTOS"
  ctx.fillStyle = "rgba(0, 240, 255, 0.6)";
  ctx.font = "10px Orbitron, Arial";
  ctx.letterSpacing = "2px";
  ctx.fillText("PONTOS", 20, 28);

  // número dos pontos em destaque
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 20px Orbitron, Arial";
  ctx.fillText(pontos, 20, 50);


  // ---- PAINEL DE VIDAS (canto superior direito) ----

  // fundo semitransparente do painel de vidas
  ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
  ctx.beginPath();
  ctx.roundRect(430, 10, 160, 50, 8);
  ctx.fill();

  // borda neon do painel de vidas
  ctx.strokeStyle = "rgba(0, 240, 255, 0.5)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(430, 10, 160, 50, 8);
  ctx.stroke();

  // texto "VIDAS"
  ctx.fillStyle = "rgba(0, 240, 255, 0.6)";
  ctx.font = "10px Orbitron, Arial";
  ctx.fillText("VIDAS", 440, 28);

  // exibe corações para mostrar as vidas de forma visual
  ctx.font = "20px Arial";
  var coracoes = "";

  // adiciona um coração para cada vida restante
  for (var i = 0; i < vidas; i++) {
    coracoes = coracoes + "❤️";
  }

  // desenha os corações na tela
  ctx.fillText(coracoes, 440, 50);
}


// ================================================
// FUNÇÃO: DESENHAR
// Essa função é chamada a cada frame
// Ela limpa a tela e desenha todos os elementos
// ================================================
function desenhar() {

  // ---- FUNDO ----

  // preenche o fundo de preto
  ctx.fillStyle = "#060810";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // ---- GRADE DE FUNDO DECORATIVA ----

  // desenha linhas verticais e horizontais formando uma grade
  ctx.strokeStyle = "rgba(0, 240, 255, 0.04)";
  ctx.lineWidth = 1;

  // linhas verticais da grade (a cada 60 pixels)
  for (var x = 0; x < canvas.width; x = x + 60) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }

  // linhas horizontais da grade (a cada 60 pixels)
  for (var y = 0; y < canvas.height; y = y + 60) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // ---- DIVISÓRIAS DAS PISTAS ----

  // define a cor das linhas divisórias (azul neon brilhante)
  ctx.strokeStyle = "#00f0ff";

  // espessura das linhas
  ctx.lineWidth = 2;

  // efeito de brilho nas linhas
  ctx.shadowColor = "#00f0ff";
  ctx.shadowBlur = 10;

  // desenha a primeira linha divisória (entre pista 0 e pista 1)
  ctx.beginPath();
  ctx.moveTo(200, 0);
  ctx.lineTo(200, canvas.height);
  ctx.stroke();

  // desenha a segunda linha divisória (entre pista 1 e pista 2)
  ctx.beginPath();
  ctx.moveTo(400, 0);
  ctx.lineTo(400, canvas.height);
  ctx.stroke();

  // desativa o efeito de brilho para os próximos elementos
  ctx.shadowBlur = 0;

  // ---- JOGADOR ----

  // adiciona brilho neon embaixo do jogador
  ctx.shadowColor = "#00f0ff";
  ctx.shadowBlur = 20;

  // desenha a imagem do jogador na tela
  ctx.drawImage(
    imgJogador,
    jogador.x,
    jogador.y,
    jogador.largura,
    jogador.altura
  );

  // desativa o brilho
  ctx.shadowBlur = 0;

  // ---- ITENS (CLTs e inimigos) ----

  // percorre a lista de itens e desenha cada um
  for (var i = 0; i < itens.length; i++) {

    // pega o item atual
    var item = itens[i];

    // se for CLT, adiciona brilho verde-azulado
    if (item.tipo === "clt") {
      ctx.shadowColor = "#00ffaa";
      ctx.shadowBlur = 15;
    } else {
      // se for inimigo, sem brilho especial
      ctx.shadowBlur = 0;
    }

    // desenha a imagem do item na tela
    ctx.drawImage(
      item.imagem,
      item.x,
      item.y,
      item.largura,
      item.altura
    );
  }

  // garante que o brilho está desativado
  ctx.shadowBlur = 0;

  // ---- HUD (placar) ----

  // chama a função que desenha pontos e vidas
  desenharHud();
}


// ================================================
// FUNÇÃO: LOOP DO JOGO
// Essa é a função principal que mantém o jogo
// rodando. Ela chama atualizar() e desenhar()
// a cada frame (geralmente 60x por segundo)
// ================================================
function loopDoJogo() {

  // atualiza toda a lógica do jogo (posições, colisões, pontos)
  atualizar();

  // redesenha tudo na tela
  desenhar();

  // pede ao navegador para chamar essa função novamente no próximo frame
  requestAnimationFrame(loopDoJogo);
}


// ================================================
// INÍCIO DO JOGO
// Essa linha dispara o loop do jogo pela primeira vez
// ================================================
requestAnimationFrame(loopDoJogo);
