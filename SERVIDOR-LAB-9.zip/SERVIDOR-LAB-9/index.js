// ---------------------------------------------------
// IMPORTAÇÕES
// ---------------------------------------------------

const express = require("express");

const path = require("path");

const { MongoClient } = require("mongodb");


// ---------------------------------------------------
// SERVIDOR
// ---------------------------------------------------

const app = express();


// ---------------------------------------------------
// CONFIGURAÇÕES
// ---------------------------------------------------

// EJS
app.set("view engine", "ejs");


// formulário
app.use(express.urlencoded({ extended: true }));


// arquivos estáticos
app.use(express.static("public"));


// ---------------------------------------------------
// MONGODB
// ---------------------------------------------------

// conexão mongodb atlas
const uri = "mongodb+srv://joaoriobusiness:fullstackrio@clusterfullstackrio.sv5phel.mongodb.net/?retryWrites=true&w=majority";


// cliente mongodb
const client = new MongoClient(uri);


// variáveis do banco
let db;

let posts;


// conectar no banco
async function conectarMongo() {

  try {

    await client.connect();

    db = client.db("blogDB");

    posts = db.collection("posts");

    console.log("MongoDB conectado com sucesso!");

  }

  catch (erro) {

    console.log("Erro ao conectar no MongoDB");

    console.log(erro);

  }

}


// chama conexão
conectarMongo();


// ---------------------------------------------------
// ROTAS GET
// ---------------------------------------------------

// página principal
app.get("/", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "projects.html"));

});


// login
app.get("/login", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "Login.html"));

});


// cadastro
app.get("/cadastra", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "Cadastro.html"));

});


// página cadastrar post
app.get("/cadastrar_post", (req, res) => {

  res.sendFile(
    path.join(__dirname, "public", "lab9", "cadastrar_post.html")
  );

});


// ---------------------------------------------------
// BLOG
// ---------------------------------------------------

app.get("/blog", async (req, res) => {

  try {

    // busca posts
    const listaPosts = await posts.find({}).toArray();


    // renderiza página
    res.render("blog", {

      posts: listaPosts

    });

  }

  catch (erro) {

    res.status(500).send("Erro ao buscar posts");

    console.log(erro);

  }

});


// ---------------------------------------------------
// LOGIN
// ---------------------------------------------------

app.post("/verificar-login", (req, res) => {

  let usuario = req.body.usuario;

  let senha = req.body.senha;


  if (usuario !== "" && senha !== "") {

    res.render("resposta", {

      status: "Login realizado com sucesso!"

    });

  }

  else {

    res.render("resposta", {

      status: "Erro! Preencha todos os campos."

    });

  }

});


// ---------------------------------------------------
// SALVAR POST
// ---------------------------------------------------

app.post("/salvar-post", async (req, res) => {

  try {

    // pega dados
    let titulo = req.body.titulo;

    let resumo = req.body.resumo;

    let conteudo = req.body.conteudo;


    // salva no banco
    await posts.insertOne({

      titulo: titulo,

      resumo: resumo,

      conteudo: conteudo,

      data: new Date()

    });


    console.log("Post salvo com sucesso");


    // volta para blog
    res.redirect("/blog");

  }

  catch (erro) {

    res.status(500).send("Erro ao salvar post");

    console.log(erro);

  }

});


// ---------------------------------------------------
// PORTA
// ---------------------------------------------------

const PORT = 3000;


// ---------------------------------------------------
// INICIA SERVIDOR
// ---------------------------------------------------

app.listen(PORT, () => {

  console.log("Servidor rodando na porta 3000");

});