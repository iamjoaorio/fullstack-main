// importa o express
const express = require("express");

// importa o path
const path = require("path");

// cria o servidor
const app = express();


// configura o EJS
app.set("view engine", "ejs");


// middleware para formulários
app.use(express.urlencoded({ extended: true }));


// arquivos estáticos
app.use(express.static("public"));


// porta
const PORT = 3000;

app.listen(PORT, () => {

  console.log("Servidor rodando na porta 3000");

});

// rota principal
app.get("/", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "projects.html"));

});


// rota login
app.get("/login", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "Login.html"));

});


// rota cadastro
app.get("/cadastra", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "Cadastro.html"));

});


// rota post login
app.post("/verificar-login", (req, res) => {

  let usuario = req.body.usuario;
  let senha = req.body.senha;


  if (usuario !== "" && senha !== "") {

    res.render("resposta", {

      status: "Login realizado com sucesso!"

    });

  }

  else {

    res.render("resposta", {

      status: "Erro! Preencha todos os campos."

    });

  }

});


// inicia servidor
app.listen(PORT, () => {
});