// ---------------------------------------------------
// IMPORTAÇÕES
// ---------------------------------------------------

const express = require("express");

const path = require("path");

const { MongoClient, ObjectId } = require("mongodb");


// ---------------------------------------------------
// SERVIDOR
// ---------------------------------------------------

const app = express();


// ---------------------------------------------------
// CONFIGURAÇÕES
// ---------------------------------------------------

// EJS
app.set("view engine", "ejs");


// formulário
app.use(express.urlencoded({ extended: true }));


// arquivos estáticos
app.use(express.static("public"));


// ---------------------------------------------------
// MONGODB
// ---------------------------------------------------

// conexão mongodb atlas
const uri = "mongodb+srv://joaoriobusiness:fullstackrio@clusterfullstackrio.sv5phel.mongodb.net/?appName=ClusterFullstackRio";


const client = new MongoClient(uri, {
  tlsAllowInvalidCertificates: true
});

let db;

let posts;

let usuarios;

let carros;


// conectar mongo
async function conectarMongo() {

  try {

    await client.connect();

    db = client.db("concessionariaDB");

    posts = db.collection("posts");

    usuarios = db.collection("usuarios");

    carros = db.collection("carros");

    console.log("MongoDB conectado com sucesso!");

  }

  catch (erro) {

    console.log("Erro ao conectar no MongoDB");

    console.log(erro);

  }

}

conectarMongo();


// ---------------------------------------------------
// ROTAS GET
// ---------------------------------------------------

// página principal
app.get("/", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "projects.html"));

});


// login
app.get("/login", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "Login.html"));

});


// cadastro
app.get("/cadastra", (req, res) => {

  res.sendFile(path.join(__dirname, "public", "Cadastro.html"));

});


// página cadastrar post
app.get("/cadastrar_post", (req, res) => {

  res.sendFile(
    path.join(__dirname, "public", "lab9", "cadastrar_post.html")
  );

});


// ---------------------------------------------------
// BLOG
// ---------------------------------------------------

app.get("/blog", async (req, res) => {

  try {

    // busca posts
    const listaPosts = await posts.find({}).toArray();


    // renderiza página
    res.render("blog", {

      posts: listaPosts

    });

  }

  catch (erro) {

    res.status(500).send("Erro ao buscar posts");

    console.log(erro);

  }

});


// ---------------------------------------------------
// LOGIN
// ---------------------------------------------------

app.post("/verificar-login", (req, res) => {

  let usuario = req.body.usuario;

  let senha = req.body.senha;


  if (usuario !== "" && senha !== "") {

    res.render("resposta", {

      status: "Login realizado com sucesso!"

    });

  }

  else {

    res.render("resposta", {

      status: "Erro! Preencha todos os campos."

    });

  }

});


// ---------------------------------------------------
// SALVAR POST
// ---------------------------------------------------

app.post("/salvar-post", async (req, res) => {

  try {

    // pega dados
    let titulo = req.body.titulo;

    let resumo = req.body.resumo;

    let conteudo = req.body.conteudo;


    // salva no banco
    await posts.insertOne({

      titulo: titulo,

      resumo: resumo,

      conteudo: conteudo,

      data: new Date()

    });


    console.log("Post salvo com sucesso");


    // volta para blog
    res.redirect("/blog");

  }

  catch (erro) {

    res.status(500).send("Erro ao salvar post");

    console.log(erro);

  }

});


// ---------------------------------------------------
// PORTA
// ---------------------------------------------------

const PORT = 3000;


// ---------------------------------------------------
// INICIA SERVIDOR
// ---------------------------------------------------

app.listen(PORT, () => {

  console.log("Servidor rodando na porta 3000");

});


// ---------------------------------------------------
// USUÁRIOS
// ---------------------------------------------------

// página cadastro usuário
app.get("/cadastro-usuario", (req, res) => {

  res.sendFile(
    path.join(__dirname, "public", "lab10", "cadastro_usuario.html")
  );

});


// salvar usuário
app.post("/salvar-usuario", async (req, res) => {

  try {

    await usuarios.insertOne({

      nome: req.body.nome,

      login: req.body.login,

      senha: req.body.senha

    });

    res.redirect("/login-usuario");

  }

  catch (erro) {

    res.send("Erro ao salvar usuário");

  }

});


// página login usuário
app.get("/login-usuario", (req, res) => {

  res.sendFile(
    path.join(__dirname, "public", "lab10", "login_usuario.html")
  );

});


// logar usuário
app.post("/logar-usuario", async (req, res) => {

  try {

    const usuario = await usuarios.findOne({

      login: req.body.login,

      senha: req.body.senha

    });

    if (usuario) {

      res.redirect("/carros");

    }

    else {

      res.send("Usuário ou senha inválidos");

    }

  }

  catch (erro) {

    res.send("Erro no login");

  }

});


// ---------------------------------------------------
// CARROS
// ---------------------------------------------------

// listar carros
app.get("/carros", async (req, res) => {

  try {

    const listaCarros = await carros.find({}).toArray();

    res.render("carros", {

      carros: listaCarros

    });

  }

  catch (erro) {

    res.send("Erro ao listar carros");

  }

});


// cadastrar carro
app.post("/cadastrar-carro", async (req, res) => {

  try {

    await carros.insertOne({

      marca: req.body.marca,

      modelo: req.body.modelo,

      ano: req.body.ano,

      Qtde_disponivel: Number(req.body.Qtde_disponivel)

    });

    res.redirect("/carros");

  }

  catch (erro) {

    res.send("Erro ao cadastrar carro");

  }

});


// remover carro
app.post("/remover-carro/:id", async (req, res) => {

  try {

    await carros.deleteOne({

      _id: new ObjectId(req.params.id)

    });

    res.redirect("/carros");

  }

  catch (erro) {

    res.send("Erro ao remover carro");

  }

});


// atualizar carro
app.post("/atualizar-carro/:id", async (req, res) => {

  try {

    await carros.updateOne(

      {

        _id: new ObjectId(req.params.id)

      },

      {

        $set: {

          marca: req.body.marca,

          modelo: req.body.modelo,

          ano: req.body.ano,

          Qtde_disponivel: Number(req.body.Qtde_disponivel)

        }

      }

    );

    res.redirect("/carros");

  }

  catch (erro) {

    res.send("Erro ao atualizar carro");

  }

});


// vender carro
app.post("/vender-carro/:id", async (req, res) => {

  try {

    const carro = await carros.findOne({

      _id: new ObjectId(req.params.id)

    });

    if (carro.Qtde_disponivel > 0) {

      await carros.updateOne(

        {

          _id: new ObjectId(req.params.id)

        },

        {

          $inc: {

            Qtde_disponivel: -1

          }

        }

      );

    }

    res.redirect("/carros");

  }

  catch (erro) {

    res.send("Erro ao vender carro");

  }

});